# Infix-To-Postfix-Calculator
In this calculator we used stack structure for converting infix expressions to postfix and prefix notation, then we used postfix to evaluate the result of the calculation.

The program runs on NetBeans.

An example of running the program:


![2](https://user-images.githubusercontent.com/45950266/153171005-26e6bc8f-851e-4f54-b82d-ca7168a02ca6.png)

